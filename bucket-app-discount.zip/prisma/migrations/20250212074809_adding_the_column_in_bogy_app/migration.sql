-- AlterTable
ALTER TABLE `bogoxy` MODIFY `amount` DOUBLE NULL DEFAULT 0;
