-- AlterTable
ALTER TABLE `bundle` MODIFY `products` JSON NULL;
