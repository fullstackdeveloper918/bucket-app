-- AlterTable
ALTER TABLE `bundle` ADD COLUMN `product_bundle_id` INTEGER NULL;
