-- AlterTable
ALTER TABLE `bogoxy` ADD COLUMN `discount_info` JSON NULL;
