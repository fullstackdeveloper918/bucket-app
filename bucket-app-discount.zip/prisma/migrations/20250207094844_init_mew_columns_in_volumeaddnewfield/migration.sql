-- AlterTable
ALTER TABLE `volumediscount` ADD COLUMN `discount_info` JSON NULL;
