-- AlterTable
ALTER TABLE `review` MODIFY `textSize` VARCHAR(191) NULL;
