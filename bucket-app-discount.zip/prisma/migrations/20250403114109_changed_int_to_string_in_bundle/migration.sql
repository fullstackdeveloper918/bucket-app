-- AlterTable
ALTER TABLE `bundle` MODIFY `product_bundle_id` VARCHAR(191) NULL;
