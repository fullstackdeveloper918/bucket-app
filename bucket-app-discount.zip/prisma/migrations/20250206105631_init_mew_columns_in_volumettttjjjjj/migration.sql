-- AlterTable
ALTER TABLE `volumediscount` ADD COLUMN `call_to_action_button` JSON NULL;
