-- AlterTable
ALTER TABLE `visitoraction` ADD COLUMN `userName` VARCHAR(191) NULL;
