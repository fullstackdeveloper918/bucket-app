-- AlterTable
ALTER TABLE `visitoraction` ADD COLUMN `actionNumber` INTEGER NULL;
