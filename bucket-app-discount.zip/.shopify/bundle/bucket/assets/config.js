// https://decade-terrorism-white-should.trycloudflare.com

const app_url="https://row-quiet-brief-holdem.trycloudflare.com"
window.shopifyConfig = {
    AppUrl:app_url
};
