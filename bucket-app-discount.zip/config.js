const config = {
    apiKey: "95ec3e496004fdaa9310abd63f41557a",
    host: new URLSearchParams(location.search).get("host"),
    forceRedirect: true,
  };
  
  export default config;