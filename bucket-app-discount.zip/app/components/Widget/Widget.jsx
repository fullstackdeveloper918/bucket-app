import styles from "../../styles/main.module.css";
import dropdown from "../../routes/assets/drop_downImg.svg";
import pllaceholderImg from "../../routes/assets/images_place.svg";
import preview_mockup from "../../routes/assets/preview_mockup.svg";
// import stars from "../../routes/assets/star_svg.svg";
import stars from "../../routes/assets/stars.png";
import Productpreview from "../../routes/assets/product_sample.png";
import check_svg from "../../routes/assets/circle-check-solid.svg";
import grid_img from "../../routes/assets/gridImg.png";
import listImg from "../../routes/assets/listImg.png";
import { Form } from "@remix-run/react";
import { useState } from "react";

const Widget = () => {


  return (
    <>
     
    </>
  );
};

export default Widget;
