import React from 'react'

const FormInput = () => {
  return (
    <>
        
    </>
  )
}

export default FormInput