import React from 'react'
import './Loader.css'

const LoaderBlack = () => {
  return (
    <div className='black-loader'>
    <span class="loader"></span>
    </div>
  )
}

export default LoaderBlack