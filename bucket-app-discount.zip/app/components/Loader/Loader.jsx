import React from 'react'
import './Loader.css'

const Loader = () => {
  return (
    <span class="loader"></span>
  )
}

export default Loader