import React, { useEffect, useState } from "react";
import styles from "../../styles/main.module.css";
import AddProduct from "./AddProduct";
import { Form } from "@remix-run/react";
import { toast as notify } from "sonner";


const BuyProduct = ({  products,
  actionResponse,
  setId,
  setActiveTab,
  setCompletedStep, }) => {


  // const [values, setValues] = useState({
  //   bundle_name: "",
  //   buysx: [],
  //   gety: [],
  //   where_to_display: "Bundle Product Pages",
  // });

    

  return (
    <>
      
    </>
  );
};

export default BuyProduct;
