import React, { useState } from "react";
import styles from "../../styles/main.module.css";
import infoImage from "../../routes/assets/infoImage.png";
import AddGradient from "../../routes/assets/AddGradient.png";
const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(2, 1fr)",
};

const Modal = ({ onClose }) => {
  const [launch, setLaunch] = useState("launch");
  return (
   <div>hh</div>
  );
};

export default Modal;
