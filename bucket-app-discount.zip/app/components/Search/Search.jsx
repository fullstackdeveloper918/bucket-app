import React from 'react'

const Search = () => {
  return (
    <>
      <input type="text" placeholder='Seach...' />   
    </>
  )
}

export default Search